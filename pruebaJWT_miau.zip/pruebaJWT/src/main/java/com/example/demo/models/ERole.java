package com.example.demo.models;

public enum ERole  {
	ADMIN,
	USER,
	INVITED

}
